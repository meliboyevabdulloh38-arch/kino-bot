import { Button } from "@/components/ui/button";
import type { Movie } from "../../../drizzle/schema";
import { ArrowLeft, ChevronRight, Clapperboard, ExternalLink, Film, Flame, Play, Search, Sparkles, Star, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

const fallbackPoster = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=700&q=85";

function Poster({ movie, className = "" }: { movie: Movie; className?: string }) {
  return (
    <img
      className={`poster-image ${className}`}
      src={movie.posterUrl || fallbackPoster}
      alt={movie.title}
      loading="lazy"
      onError={event => { event.currentTarget.src = fallbackPoster; }}
    />
  );
}

function MovieCard({ movie, onOpen }: { movie: Movie; onOpen: (movie: Movie) => void }) {
  return (
    <button className="movie-card" onClick={() => onOpen(movie)} aria-label={`${movie.title} tafsilotlarini ochish`}>
      <div className="movie-poster-wrap">
        <Poster movie={movie} />
        <span className="movie-code">{movie.code}</span>
        <span className="movie-rating"><Star size={12} fill="currentColor" /> {movie.rating || "—"}</span>
      </div>
      <div className="movie-card-copy">
        <strong>{movie.title}</strong>
        <span>{movie.year || "Yangi"} <i>·</i> {movie.genre?.split("·")[0]?.trim() || "Kino"}</span>
      </div>
    </button>
  );
}

function Rail({ title, icon, movies, onOpen, accent = "" }: { title: string; icon: React.ReactNode; movies: Movie[]; onOpen: (movie: Movie) => void; accent?: string }) {
  if (!movies.length) return null;
  return (
    <section className="content-section">
      <div className="section-heading">
        <div className={`section-icon ${accent}`}>{icon}</div>
        <h2>{title}</h2>
        <span className="section-line" />
        <span className="section-count">{movies.length} ta</span>
      </div>
      <div className="poster-rail">
        {movies.map(movie => <MovieCard key={movie.id} movie={movie} onOpen={onOpen} />)}
      </div>
    </section>
  );
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [showSearch, setShowSearch] = useState(false);
  const recommendations = trpc.movies.recommendations.useQuery();
  const popular = trpc.movies.popular.useQuery();
  const latest = trpc.movies.latest.useQuery();
  const search = trpc.movies.search.useQuery({ query: query.trim() }, { enabled: query.trim().length >= 2 });
  const incrementViews = trpc.movies.incrementViews.useMutation();

  useEffect(() => {
    const telegram = window.Telegram?.WebApp;
    telegram?.ready();
    telegram?.expand();
    document.documentElement.style.setProperty("--telegram-bg", telegram?.themeParams?.bg_color || "#111111");
  }, []);

  const searchResults = useMemo(() => search.data ?? [], [search.data]);
  const isSearching = query.trim().length >= 2;

  const openMovie = (movie: Movie) => {
    setSelectedMovie(movie);
    incrementViews.mutate({ id: movie.id });
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href="/" className="brand" aria-label="KinoBot bosh sahifa">
          <span className="brand-mark"><Play size={16} fill="currentColor" /></span>
          <span>KINOBOT</span>
        </Link>
        <div className="topbar-actions">
          <span className="live-dot">UZ</span>
          <Link href="/admin" className="admin-link">Admin <ChevronRight size={14} /></Link>
        </div>
      </header>

      <main className="main-content">
        <section className="hero-block">
          <div className="eyebrow"><span className="eyebrow-dot" /> TELEGRAM MINI APP <span className="eyebrow-slash">/</span> 2026</div>
          <h1>Bugun nimani<br /><em>ko‘ramiz?</em></h1>
          <p className="hero-note">Kino kodini kiriting. Film shu yerda.</p>
          <div className="search-shell">
            <Search size={20} />
            <input
              value={query}
              onChange={event => setQuery(event.target.value)}
              onFocus={() => setShowSearch(true)}
              placeholder="Kino kodi yoki nomi..."
              aria-label="Kino kodi yoki nomi bo‘yicha qidirish"
            />
            <kbd>KOD</kbd>
            {query && <button className="clear-search" onClick={() => { setQuery(""); setShowSearch(false); }} aria-label="Qidiruvni tozalash"><X size={17} /></button>}
          </div>
          <div className="hero-meta"><span><Clapperboard size={14} /> {latest.data?.length || 0}+ film katalogda</span><span><Sparkles size={14} /> Har kuni yangi tavsiyalar</span></div>
        </section>

        {isSearching ? (
          <section className="search-results content-section">
            <div className="section-heading"><div className="section-icon lime"><Search size={18} /></div><h2>Qidiruv natijalari</h2><span className="section-line" /></div>
            {search.isLoading ? <div className="empty-state">Qidirilmoqda...</div> : searchResults.length ? <div className="movie-grid">{searchResults.map(movie => <MovieCard key={movie.id} movie={movie} onOpen={openMovie} />)}</div> : <div className="empty-state"><strong>Hech narsa topilmadi.</strong><span>Kodni yoki nomini boshqacha yozib ko‘ring.</span></div>}
          </section>
        ) : (
          <>
            <Rail title="Siz uchun" icon={<Sparkles size={18} />} movies={recommendations.data ?? []} onOpen={openMovie} accent="purple" />
            <Rail title="Mashhur kinolar" icon={<Flame size={18} />} movies={popular.data ?? []} onOpen={openMovie} accent="orange" />
            <Rail title="Yangi qo‘shilganlar" icon={<Film size={18} />} movies={latest.data ?? []} onOpen={openMovie} accent="lime" />
          </>
        )}

        <footer className="app-footer"><span>KINOBOT / KINO KODI BILAN</span><span>Faqat ruxsatli tomosha havolalari</span></footer>
      </main>

      {selectedMovie && <MovieDetails movie={selectedMovie} onClose={() => setSelectedMovie(null)} />}
      {showSearch && query.length === 0 && <button className="search-backdrop" onClick={() => setShowSearch(false)} aria-label="Qidiruvni yopish" />}
    </div>
  );
}

function MovieDetails({ movie, onClose }: { movie: Movie; onClose: () => void }) {
  const botUsername = (import.meta.env.VITE_TELEGRAM_BOT_USERNAME || "").replace(/^@/, "");
  const botWatchUrl = botUsername && movie.code ? `https://t.me/${botUsername}?start=movie_${encodeURIComponent(movie.code)}` : "";
  return (
    <div className="detail-overlay" role="dialog" aria-modal="true" aria-label={`${movie.title} tafsilotlari`}>
      <div className="detail-sheet">
        <div className="detail-cover" style={{ backgroundImage: `linear-gradient(180deg, rgba(12,12,14,.05), rgba(12,12,14,.96)), url(${movie.backdropUrl || movie.posterUrl || fallbackPoster})` }}>
          <button className="close-detail" onClick={onClose} aria-label="Yopish"><X size={20} /></button>
          <div className="detail-cover-content"><span className="detail-code">{movie.code}</span><h2>{movie.title}</h2><div className="detail-subline"><span>{movie.year || "—"}</span><span>·</span><span>{movie.genre || "Kino"}</span><span>·</span><span><Star size={13} fill="currentColor" /> {movie.rating || "—"}</span></div></div>
        </div>
        <div className="detail-body">
          <div className="detail-poster"><Poster movie={movie} /></div>
          <div className="detail-copy"><p>{movie.description || "Film tavsifi tez orada qo‘shiladi."}</p><div className="detail-tags"><span>{movie.language || "O‘zbekcha"}</span><span>{movie.country || "—"}</span><span>{movie.views.toLocaleString("uz-UZ")} ko‘rish</span></div></div>
        </div>
        <div className="detail-actions">
          {botWatchUrl ? <a className="watch-button" href={botWatchUrl} target="_blank" rel="noreferrer"><Play size={17} fill="currentColor" /> Botda ko‘rish <ExternalLink size={15} /></a> : movie.watchUrl ? <a className="watch-button" href={movie.watchUrl} target="_blank" rel="noreferrer"><Play size={17} fill="currentColor" /> Tomosha qilish <ExternalLink size={15} /></a> : <Button className="watch-button" disabled><Play size={17} fill="currentColor" /> Havola tez orada</Button>}
          {movie.trailerUrl && <a className="trailer-button" href={movie.trailerUrl} target="_blank" rel="noreferrer">Treyler</a>}
        </div>
        <div className="detail-hint"><span>KINO KODI</span><strong>{movie.code}</strong><span>Do‘stlaringiz bilan ulashing</span></div>
      </div>
    </div>
  );
}
