import {
  attachSeriesEpisodeVideo,
  createAnnouncement,
  createMovie,
  getMovieByCode,
  getForcedSubscriptionSettings,
  getSeriesDetailByCode,
  getSeriesEpisodeById,
  incrementSeriesEpisodeViews,
  listTelegramChatIds,
  markTelegramEpisodeDelivered,
  markTelegramMovieDelivered,
  setTelegramSubscription,
  updateMovie,
  upsertTelegramUser,
  wasTelegramEpisodeDelivered,
  wasTelegramMovieDelivered,
} from "./db";
const token = process.env.TELEGRAM_BOT_TOKEN;
const adminId = process.env.TELEGRAM_ADMIN_ID;
const api = token ? `https://api.telegram.org/bot${token}` : "";
const envSubscriptionChannel = (process.env.TELEGRAM_FORCE_SUBSCRIPTION_CHANNEL || "").trim();
const envSubscriptionUrl = (process.env.TELEGRAM_FORCE_SUBSCRIPTION_URL || "").trim();
async function getRequiredSubscriptionConfig() {
  const saved = await getForcedSubscriptionSettings();
  const channelConfig = (saved.channel || envSubscriptionChannel).trim();
  const channel = /^-?\d+$/.test(channelConfig) ? channelConfig : channelConfig ? (channelConfig.startsWith("@") ? channelConfig : `@${channelConfig}`) : "";
  const url = (saved.url || envSubscriptionUrl || (channel.startsWith("@") ? `https://t.me/${channel.slice(1)}` : "")).trim();
  return { channel, url };
}
let offset = 0;
let running = false;
async function telegram(method: string, body: Record<string, unknown>) {
  if (!api) return null;
  const response = await fetch(`${api}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  return response.json() as Promise<{ ok: boolean; result?: any; description?: string }>;
}

async function hasRequiredSubscription(userId: string, config: { channel: string; url: string }) {
  if (!config.channel) return true;
  const result = await telegram("getChatMember", { chat_id: config.channel, user_id: userId });
  if (!result?.ok) {
    console.error("[Telegram subscription] getChatMember failed:", result?.description || "unknown error");
    return false;
  }
  const status = result.result?.status;
  return status === "creator" || status === "administrator" || status === "member" || (status === "restricted" && result.result?.is_member === true);
}
async function sendSubscriptionPrompt(chatId: number | string, config: { channel: string; url: string }) {
  const keyboard: Array<Array<Record<string, string>>> = [];
  if (config.url) keyboard.push([{ text: "📢 Kanalga obuna bo‘lish", url: config.url }]);
  keyboard.push([{ text: "✅ Obunani tekshirish", callback_data: "check_subscription" }]);
  await telegram("sendMessage", {
    chat_id: chatId,
    text: "🔒 Kinolarni ko‘rish uchun avval majburiy kanalga obuna bo‘ling. Obuna bo‘lgach, pastdagi tekshirish tugmasini bosing.",
    reply_markup: { inline_keyboard: keyboard },
  });
}
async function requireSubscription(chatId: number | string, userId: string) {
  const config = await getRequiredSubscriptionConfig();
  if (!config.channel) return true;
  const subscribed = await hasRequiredSubscription(userId, config);
  if (!subscribed) {
    await setTelegramSubscription(String(chatId), false);
    await sendSubscriptionPrompt(chatId, config);
  }
  return subscribed;
}

async function sendEpisode(chatId: number | string, episodeId: number, forceResend = false) {
  const found = await getSeriesEpisodeById(episodeId);
  const episode = found?.episode;
  const season = found?.season;
  const series = found?.series;
  if (!episode || !season || !series) {
    await telegram("sendMessage", { chat_id: chatId, text: "Bu qism topilmadi yoki nashrdan olingan." });
    return;
  }
  if (!episode.telegramFileId) {
    await telegram("sendMessage", { chat_id: chatId, text: `📺 ${series.title} — ${season.seasonNumber}-fasl, ${episode.episodeNumber}-qism videosi hali yuklanmagan.` });
    return;
  }
  const chatKey = String(chatId);
  if (!forceResend && await wasTelegramEpisodeDelivered(chatKey, episode.id)) {
    await telegram("sendMessage", {
      chat_id: chatId,
      text: `✅ ${series.title} — ${season.seasonNumber}-fasl, ${episode.episodeNumber}-qism bu chatga avval yuborilgan.`,
      reply_markup: { inline_keyboard: [[{ text: "Qayta yuborish", callback_data: `episode_again:${episode.id}` }]] },
    });
    return;
  }
  const method = episode.telegramFileType === "document" ? "sendDocument" : "sendVideo";
  const fileField = episode.telegramFileType === "document" ? "document" : "video";
  const sent = await telegram(method, {
    chat_id: chatId,
    [fileField]: episode.telegramFileId,
    caption: `✅ Qism bot chatiga yuborildi\n${series.title}\n${season.seasonNumber}-fasl, ${episode.episodeNumber}-qism`,
  });
  if (sent?.ok) {
    await markTelegramEpisodeDelivered(chatKey, episode.id);
    await incrementSeriesEpisodeViews(episode.id);
  }
}
async function sendSeriesMenu(chatId: number | string, code: string) {
  const detail = await getSeriesDetailByCode(code);
  if (!detail) {
    await telegram("sendMessage", { chat_id: chatId, text: `${code} kodi bilan serial topilmadi.` });
    return;
  }
  const rows: Array<Array<{ text: string; callback_data: string }>> = [];
  for (const group of detail.seasons) {
    rows.push([{ text: `— ${group.season.seasonNumber}-fasl —`, callback_data: "series_noop" }]);
    for (let index = 0; index < group.episodes.length; index += 2) {
      rows.push(group.episodes.slice(index, index + 2).map(episode => ({
        text: `${group.season.seasonNumber}×${String(episode.episodeNumber).padStart(2, "0")}${episode.title ? ` · ${episode.title}` : ""}`,
        callback_data: `episode:${episode.id}`,
      })));
    }
  }
  await telegram("sendMessage", {
    chat_id: chatId,
    text: `🎬 ${detail.series.title}\nKod: ${detail.series.code}\n\nKo‘rish uchun fasl va qismni tanlang:`,
    reply_markup: { inline_keyboard: rows.length ? rows : [[{ text: "Qismlar hali qo‘shilmagan", callback_data: "series_noop" }]] },
  });
}
async function handleCallbackQuery(callback: any) {
  const chatId = callback.message?.chat?.id;
  const userId = String(callback.from?.id || chatId || "");
  const data = String(callback.data || "");
  if (!chatId) return;
  if (data === "check_subscription") {
    const config = await getRequiredSubscriptionConfig();
    const subscribed = await hasRequiredSubscription(userId, config);
    await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: subscribed ? "✅ Obuna tasdiqlandi" : "❌ Avval kanalga obuna bo‘ling", show_alert: !subscribed });
    if (subscribed) await telegram("sendMessage", { chat_id: chatId, text: "✅ Obuna tasdiqlandi. Endi kino yoki serial kodini yuboring yoki Mini App’dan tanlang." });
    else await sendSubscriptionPrompt(chatId, config);
    return;
  }
  if (!await requireSubscription(chatId, userId)) {
    await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: "Avval majburiy kanalga obuna bo‘ling", show_alert: true });
    return;
  }
  await telegram("answerCallbackQuery", { callback_query_id: callback.id });
  if (data === "series_noop") return;
  const episodeMatch = data.match(/^episode(_again)?:([0-9]+)$/);
  if (episodeMatch) await sendEpisode(chatId, Number(episodeMatch[2]), Boolean(episodeMatch[1]));
}
async function handleUpdate(update: any) {
  if (update.callback_query) {
    await handleCallbackQuery(update.callback_query);
    return;
  }
  const message = update.message;
  if (!message?.chat?.id) return;
  const chatId = message.chat.id;
  const fromId = String(message.from?.id ?? "");
  await upsertTelegramUser(String(chatId), message.from?.username, message.from?.first_name);
  if (message.video || message.document?.mime_type?.startsWith("video/")) {
    if (adminId && fromId !== adminId) return;
    const caption = String(message.caption || "").trim();
    const fileId = message.video?.file_id || message.document?.file_id;
    const fileType = message.video ? "video" : "document";
    const seriesEpisodeMatch = caption.toUpperCase().match(/^(SER\d+)\s+S?(\d+)\s*E?(\d+)$/);
    if (seriesEpisodeMatch) {
      const attached = await attachSeriesEpisodeVideo(seriesEpisodeMatch[1], Number(seriesEpisodeMatch[2]), Number(seriesEpisodeMatch[3]), fileId, fileType);
      await telegram("sendMessage", {
        chat_id: chatId,
        text: attached ? `✅ ${attached.series.title} — ${attached.season.seasonNumber}-fasl, ${attached.episode.episodeNumber}-qism videosi saqlandi.` : "Qism topilmadi. Avval Admin panelda serial, fasl va qismni yarating. Caption misoli: SER001 S01E01",
      });
      return;
    }
    const code = caption.toUpperCase();
    const movie = /^KINO\d+$/.test(code) ? await getMovieByCode(code) : null;
    if (!movie && !/^KINO\d+$/.test(code)) {
      const fileName = message.video?.file_name || message.document?.file_name || "";
      const title = caption || fileName.replace(/\.[a-z0-9]+$/i, "").replace(/[._-]+/g, " ").trim() || "Yangi film";
      const created = await createMovie({ title, telegramFileId: fileId, telegramFileType: fileType, isPublished: true });
      if (!created) {
        await telegram("sendMessage", { chat_id: chatId, text: "Filmni saqlashda xatolik yuz berdi." });
        return;
      }
      await telegram("sendMessage", { chat_id: chatId, text: `${created.title} saqlandi. Avtomatik kod: ${created.code}` });
      return;
    }
    if (!movie) {
      await telegram("sendMessage", { chat_id: chatId, text: `${code} kodi bilan film topilmadi. Avval Admin panelda shu kodli filmni yarating.` });
      return;
    }
    await updateMovie(movie.id, { telegramFileId: fileId, telegramFileType: fileType });
    await telegram("sendMessage", { chat_id: chatId, text: `${movie.title} uchun video saqlandi. Endi foydalanuvchi Mini App ichidan “Botda ko‘rish”ni bosadi.` });
    return;
  }
  const text = String(message.text || "").trim();
  if (/^\/stop(?:@\w+)?$/i.test(text)) {
    await setTelegramSubscription(String(chatId), false);
    await telegram("sendMessage", { chat_id: chatId, text: "E’lonlar o‘chirildi. Qayta olish uchun /start yuboring." });
    return;
  }
  const resendMatch = text.match(/^\/?(?:qayta|resend)\s+(KINO\d+|SER\d+)$/i);
  const startMatch = text.match(/^\/start(?:\s+(movie|again_movie|series|episode|again_episode)_([A-Z0-9]+))?/i);
  if (!await requireSubscription(chatId, fromId)) return;
  if (/^\/start(?:@\w+)?$/i.test(text)) {
    await telegram("sendMessage", { chat_id: chatId, text: "✅ Bot faollashtirildi. Kino yoki serial kodini yuboring yoki Mini App’dan tanlang." });
    return;
  }
  const movieCodeMatch = text.match(/^\/?(?:kino\s*)?(KINO\d+)$/i);
  const seriesCodeMatch = text.match(/^\/?(?:serial\s*)?(SER\d+)$/i);
  const episodeStart = startMatch?.[1]?.toLowerCase().includes("episode") ? Number(startMatch?.[2]) : 0;
  const forceResend = Boolean(resendMatch || startMatch?.[1]?.toLowerCase() === "again_movie" || startMatch?.[1]?.toLowerCase() === "again_episode");
  if (episodeStart) {
    await sendEpisode(chatId, episodeStart, forceResend);
    return;
  }
  const movieCode = resendMatch?.[1]?.toUpperCase().startsWith("KINO") ? resendMatch[1].toUpperCase() : startMatch?.[1]?.toLowerCase().includes("movie") ? startMatch[2].toUpperCase() : movieCodeMatch?.[1]?.toUpperCase();
  const seriesCode = resendMatch?.[1]?.toUpperCase().startsWith("SER") ? resendMatch[1].toUpperCase() : startMatch?.[1]?.toLowerCase() === "series" ? startMatch[2].toUpperCase() : seriesCodeMatch?.[1]?.toUpperCase();
  if (seriesCode) {
    await sendSeriesMenu(chatId, seriesCode);
    return;
  }
  if (!movieCode) {
    await telegram("sendMessage", { chat_id: chatId, text: "Kino yoki serial kodini yuboring. Masalan: KINO001 yoki SER001" });
    return;
  }
  const movie = await getMovieByCode(movieCode);
  if (!movie?.telegramFileId) {
    await telegram("sendMessage", { chat_id: chatId, text: `${movieCode} uchun video hali yuklanmagan.` });
    return;
  }
  const chatKey = String(chatId);
  if (!forceResend && await wasTelegramMovieDelivered(chatKey, movie.id)) {
    await telegram("sendMessage", { chat_id: chatId, text: `✅ ${movie.title} bu chatga avval yuborilgan. Yuqoridagi videoni oching.` });
    return;
  }
  const method = movie.telegramFileType === "document" ? "sendDocument" : "sendVideo";
  const fileField = movie.telegramFileType === "document" ? "document" : "video";
  const sent = await telegram(method, { chat_id: chatId, [fileField]: movie.telegramFileId, caption: `✅ Kino bot chatiga yuborildi\n${movie.title}\n${movie.year || ""}` });
  if (sent?.ok) await markTelegramMovieDelivered(chatKey, movie.id);
}
async function poll() {
  if (!api || running) return;
  running = true;
  while (running) {
    try {
      const response = await telegram("getUpdates", { offset, timeout: 25, allowed_updates: ["message", "callback_query"] });
      if (!response?.ok) throw new Error(response?.description || "Telegram API error");
      for (const update of response.result || []) {
        offset = update.update_id + 1;
        await handleUpdate(update);
      }
    } catch (error) {
      console.error("[Telegram bot]", error instanceof Error ? error.message : error);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
}
export async function broadcastAnnouncement(text: string) {
  const chatIds = await listTelegramChatIds();
  let sent = 0;
  let failed = 0;
  for (const chatId of chatIds) {
    const result = await telegram("sendMessage", { chat_id: chatId, text });
    if (result?.ok) sent += 1;
    else failed += 1;
    await new Promise(resolve => setTimeout(resolve, 60));
  }
  await createAnnouncement(text, sent, failed);
  return { sent, failed, total: chatIds.length };
}
export function startTelegramBot() {
  if (!token) {
    console.log("[Telegram bot] TELEGRAM_BOT_TOKEN is not configured yet.");
    return;
  }
  console.log("[Telegram bot] polling started");
  void poll();
}
