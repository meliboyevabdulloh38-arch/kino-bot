# KinoBot seriallar tizimi — reja

## Maqsad

Mavjud kino katalogi va Telegram bot oqimini saqlagan holda to‘liq seriallar bo‘limini qo‘shish. Admin serial yaratadi, fasllar va qismlar qo‘shadi, har bir qismga video biriktiradi; foydalanuvchi Mini App ichida serialni tanlab, fasl va qism bo‘yicha bot orqali videoni oladi.

## Tasdiqlangan mahsulot talablari

- Seriallar kinolardan alohida katalog turi sifatida ko‘rinadi.
- Har bir serialda nom, poster, fon rasmi, tavsif, janr, til, mamlakat, yil, reyting va nashr holati bo‘ladi.
- Serial ichida bir nechta fasl bo‘ladi.
- Har bir fasl ichida 1-, 2-, 3-... qismlar bo‘ladi.
- Har bir qismning nomi yoki raqami, tavsifi va Telegram videosi bo‘ladi.
- Foydalanuvchi Mini App’da serialni ochib, faslni tanlaydi va qismni tanlaydi.
- Qism tanlanganda mavjud kino oqimidagi kabi Telegram bot chatiga yuborish ishlaydi.
- Admin paneldan serial, fasl va qismlarni qo‘shish, tahrirlash, o‘chirish va nashr qilish mumkin.
- Mavjud oddiy kinolar, qayta yuborish, obuna, e’lonlar va statistika ishlashi davom etadi.

## Texnik yechim

### Database

Drizzle/MySQL’ga uchta jadval qo‘shiladi:

- `series`: serialning asosiy ma’lumotlari va statistikasi.
- `seriesSeasons`: serialga bog‘langan fasllar; `seriesId` va `seasonNumber` bilan tartiblanadi.
- `seriesEpisodes`: faslga bog‘langan qismlar; qism raqami, nomi, tavsifi, Telegram `file_id`, video turi, ko‘rishlar va nashr holati saqlanadi.

O‘chirishda bog‘liq fasl va qismlar tozalanadi. Oddiy `movies` jadvali o‘zgarmaydi.

### Backend

- Seriallar ro‘yxati, serial tafsiloti, fasllar va qismlar uchun public tRPC query’lar.
- Admin uchun serial/fasl/qism CRUD mutation’lari va admin tokeni bilan himoya.
- Har bir serial uchun faqat bitta umumiy kod bo‘ladi, masalan `SER001`; foydalanuvchi serialni shu kod bilan topadi.
- Fasl va qism raqamlari ichki tartib sifatida saqlanadi (`1-fasl`, `1-qism`), foydalanuvchiga alohida qidiruv kodi berilmaydi.
- Mini App `SER001` serialini ochganda fasl va qismlarni ko‘rsatadi; qism tanlanganda ichki episode ID orqali bot deep-link’i yaratiladi.
- Botga `SER001` yuborilganda bot serial nomi va fasl/qism tugmalarini ko‘rsatadi; tugma bosilganda tegishli Telegram videosi yuboriladi.
- Qayta yuborish Mini App’dagi qism tugmasi yoki botdagi serial menyusi orqali bajariladi; foydalanuvchi alohida episode kodini yodlamaydi.
- Qism delivery’lari mavjud kino delivery’laridan alohida, takroriy yuborishni himoyalash bilan yuritiladi.

### Admin panel

Admin panelda alohida `SERIES LIBRARY` bo‘limi bo‘ladi:

1. Serial yaratish/tahrirlash formasi.
2. Serial ichidan fasl yaratish va fasl nomini tahrirlash.
3. Fasl ichidan qism yaratish; qism kodi avtomatik ko‘rsatiladi.
4. Qismning Telegram videosi botga caption kodi bilan yuborilganda avtomatik biriktiriladi.
5. Serial, fasl va qismni o‘chirishda tasdiqlash oynasi.

### Mini App

- Asosiy sahifada `Seriallar` raili yoki alohida seriallar bo‘limi.
- Serial kartasi kino kartasi bilan bir xil vizual tilda, lekin qism/fasl belgisi bilan.
- Tafsilot oynasida fasl selector’i va qism tugmalari.
- Qism tugmasida `Botda ko‘rish` va avval yuborilgan bo‘lsa `Qayta yuborish` holati.
- Telefon ekranida fasl selector’i va qism ro‘yxati vertikal, katta bosiladigan tugmalar bilan ishlaydi.

## Dizayn yo‘nalishi

### Ko‘rib chiqilgan uslublar

- **Editorial streaming archive** — ehtimol 0.08: katalogni jurnal sahifasidek ko‘rsatish.
- **Neon terminal cinema** — ehtimol 0.07: texnik, yorqin aksentli interfeys.
- **Quiet premium dark cinema** — ehtimol 0.85: mavjud KinoBot uslubini saqlovchi qoramtir, lime aksentli katalog.

### Tanlangan uslub: Quiet premium dark cinema

- **Design Movement:** premium streaming katalogi va arxiv interfeysi.
- **Core Principles:** tez topish, qisqa va aniq metama’lumot, katta touch target’lar, kinoni markazga qo‘yish.
- **Color Philosophy:** qoramtir fon kontentni ajratadi; lime aksent faol holatni bildiradi; binafsha/orange aksentlar tavsiya va broadcast bo‘limlarini ajratadi.
- **Layout Paradigm:** gorizontal film rail’lari va serial tafsilotida qatlamli bottom-sheet; fasl/qism uchun zich, ammo scroll qilinadigan vertikal ro‘yxat.
- **Signature Elements:** lime kod yorlig‘i, katta poster/fon hero, qism raqami bilan ixcham episode row.
- **Interaction Philosophy:** har bosish natijasi darhol ko‘rinadi; yuborilgan qism qayta yuborish holatini aniq ko‘rsatadi.
- **Animation:** hero va bottom-sheet yumshoq fade/slide; fasl almashganda qismlar yengil stagger bilan chiqadi; funksional tugmalar ortiqcha bezaksiz.
- **Typography System:** Space Grotesk sarlavha va kodlar uchun, system sans-serif uzun tavsif va form matnlari uchun.
- **Brand Essence:** telefon orqali boshqariladigan, tartibli Uzbek kino va serial arxivi; shaxsiy, tezkor, tartibli.
- **Brand Voice:** qisqa va do‘stona. Misollar: “Qaysi qismdan davom etamiz?” va “Qism bot chatiga yuborildi.”
- **Wordmark & Logo:** mavjud film-belgi wordmark’i saqlanadi; serial belgisi uchun stack qilingan film-strip ikonasi ishlatiladi.
- **Signature Brand Color:** lime `var(--lime)` — kodlar, faol qism va asosiy CTA’lar uchun.

## Loyiha tuzilmasi

- `drizzle/schema.ts`: serial, fasl, qism va episode delivery jadvallari.
- `drizzle/0006_*.sql`: qo‘shimcha jadvallar migratsiyasi.
- `server/db.ts`: serial/fasl/qism query va mutation’lari.
- `server/routers.ts`: public va admin tRPC endpoint’lari.
- `server/telegramBot.ts`: bitta serial kodi, fasl/qism menyusi, file_id saqlash, yuborish va qayta yuborish.
- `client/src/pages/Home.tsx`: seriallar rail’i, serial detail, fasl va qism tanlash.
- `client/src/pages/Admin.tsx`: seriallar CRUD va qismlar boshqaruvi.
- `client/src/index.css`: serial va episode row’larining telefon uchun responsive ko‘rinishi.

## Chegaralar va ixtiyoriy keyingi bosqichlar

- Video faylning o‘zi database’ga yuklanmaydi; Telegram `file_id` saqlanadi.
- Dastlab bitta serial qismiga bitta Telegram video ko‘zda tutiladi.
- Keyingi bosqichda tomosha progressi, “davom ettirish”, aktyorlar va alohida serial statistikasi qo‘shilishi mumkin.
