CREATE TABLE `botSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`settingKey` varchar(100) NOT NULL,
	`settingValue` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `botSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `botSettings_settingKey_unique` UNIQUE(`settingKey`)
);
