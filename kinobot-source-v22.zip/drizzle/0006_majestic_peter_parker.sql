CREATE TABLE `series` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`title` varchar(255) NOT NULL,
	`originalTitle` varchar(255),
	`year` int,
	`genre` varchar(255),
	`language` varchar(80),
	`country` varchar(120),
	`description` text,
	`posterUrl` text,
	`backdropUrl` text,
	`trailerUrl` text,
	`rating` varchar(8) DEFAULT '—',
	`views` int NOT NULL DEFAULT 0,
	`isFeatured` boolean NOT NULL DEFAULT false,
	`isPublished` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `series_id` PRIMARY KEY(`id`),
	CONSTRAINT `series_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `seriesEpisodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`seasonId` int NOT NULL,
	`episodeNumber` int NOT NULL,
	`title` varchar(255),
	`description` text,
	`telegramFileId` text,
	`telegramFileType` varchar(20),
	`views` int NOT NULL DEFAULT 0,
	`isPublished` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seriesEpisodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `seasonEpisodeUnique` UNIQUE(`seasonId`,`episodeNumber`)
);
--> statement-breakpoint
CREATE TABLE `seriesSeasons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`seriesId` int NOT NULL,
	`seasonNumber` int NOT NULL,
	`title` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seriesSeasons_id` PRIMARY KEY(`id`),
	CONSTRAINT `seriesSeasonUnique` UNIQUE(`seriesId`,`seasonNumber`)
);
--> statement-breakpoint
CREATE TABLE `telegramEpisodeDeliveries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`chatId` varchar(64) NOT NULL,
	`episodeId` int NOT NULL,
	`deliveredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telegramEpisodeDeliveries_id` PRIMARY KEY(`id`),
	CONSTRAINT `chatEpisodeUnique` UNIQUE(`chatId`,`episodeId`)
);
