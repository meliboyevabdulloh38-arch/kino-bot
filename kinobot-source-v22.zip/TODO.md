
## 11. Telegram majburiy kanal obunasi

- [x] Admin Render environment variables orqali majburiy kanal username/ID va kanal havolasini sozlay olishi kerak.
- [x] Admin Mini App ichidagi Admin paneldan ham kanal username/ID va kanal havolasini saqlay olishi kerak.
- [x] Foydalanuvchi kino yoki serial olishdan oldin majburiy kanal a’zoligi Telegram `getChatMember` orqali tekshirilishi kerak.
- [x] Obuna bo‘lmagan foydalanuvchiga “Kanalga obuna bo‘lish” va “Obunani tekshirish” tugmalari ko‘rsatilishi kerak.
- [x] “Obunani tekshirish” bosilganda obuna tasdiqlansa, foydalanuvchi kod, film, serial va qism oqimidan foydalanishi kerak.
- [x] Obunasi tasdiqlanmagan foydalanuvchi film yoki serial videosini olmasligi kerak.
- [x] Majburiy kanal sozlamasi kiritilmagan bo‘lsa, mavjud bot ishlashi buzilmasligi kerak.

## 12. Barcha kinolar bo‘limi

- [x] Mini App’da “Barcha kinolar” bo‘limi bo‘lishi kerak.
- [x] Ushbu bo‘limda barcha nashr qilingan filmlar bitta joyda jamlanishi kerak.
- [x] Mavjud “Siz uchun”, “Mashhur kinolar” va “Yangi qo‘shilganlar” bo‘limlari saqlanishi kerak.
