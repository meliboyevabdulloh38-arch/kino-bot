import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertMovie, InsertSeries, InsertSeriesEpisode, InsertSeriesSeason, InsertUser, Movie, movies, series, seriesEpisodes, seriesSeasons, Series, telegramAnnouncements, telegramDeliveries, telegramEpisodeDeliveries, telegramUsers, User, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
const demoTelegramDeliveries = new Set<string>();

const demoMovies: Movie[] = [
  {
    id: 1,
    code: "KINO001",
    title: "Interstellar",
    originalTitle: "Interstellar",
    year: 2014,
    genre: "Fantastika · Drama",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Insoniyat kelajagi uchun yangi sayyora izlayotgan tadqiqotchilar haqidagi epik kosmik sarguzasht.",
    posterUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Interstellar+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Interstellar+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.7",
    views: 12840,
    isFeatured: true,
    isPublished: true,
    createdAt: new Date("2026-09-01"),
    updatedAt: new Date("2026-09-01"),
  },
  {
    id: 2,
    code: "KINO002",
    title: "Dune: Part Two",
    originalTitle: "Dune: Part Two",
    year: 2024,
    genre: "Fantastika · Sarguzasht",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Pol Atreides Chani va fremenlar bilan birlashib, oilasi taqdiriga qarshi fitnaga yuz tutadi.",
    posterUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Dune+Part+Two+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Dune+Part+Two+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.8",
    views: 9820,
    isFeatured: true,
    isPublished: true,
    createdAt: new Date("2026-09-04"),
    updatedAt: new Date("2026-09-04"),
  },
  {
    id: 3,
    code: "KINO003",
    title: "The Batman",
    originalTitle: "The Batman",
    year: 2022,
    genre: "Jangari · Detektiv",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Gotham shahrida sirli jinoyatlar izidan borayotgan Batman o‘z shahrining qorong‘i sirlarini ochadi.",
    posterUrl: "https://images.unsplash.com/photo-1531259683007-016a7b628fc3?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=The+Batman+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=The+Batman+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "7.8",
    views: 7640,
    isFeatured: false,
    isPublished: true,
    createdAt: new Date("2026-09-06"),
    updatedAt: new Date("2026-09-06"),
  },
  {
    id: 4,
    code: "KINO004",
    title: "The Grand Budapest Hotel",
    originalTitle: "The Grand Budapest Hotel",
    year: 2014,
    genre: "Komediya · Drama",
    language: "O‘zbekcha tarjima",
    country: "Germaniya",
    description: "Mehmonxona konsyeri va uning yosh yordamchisi Yevropadagi eng katta meros mojarosiga tushib qoladi.",
    posterUrl: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Grand+Budapest+Hotel+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Grand+Budapest+Hotel+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.1",
    views: 5320,
    isFeatured: false,
    isPublished: true,
    createdAt: new Date("2026-09-10"),
    updatedAt: new Date("2026-09-10"),
  },
  {
    id: 5,
    code: "KINO005",
    title: "Spider-Man: Across the Spider-Verse",
    originalTitle: "Spider-Man: Across the Spider-Verse",
    year: 2023,
    genre: "Animatsiya · Fantastika",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Miles Morales multiverse bo‘ylab yangi jamoa va katta tanlov qarshisida qoladi.",
    posterUrl: "https://images.unsplash.com/photo-1534809027769-b00d750a6bac?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1518709594023-6eab9bab7b23?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Spider-Man+Across+the+Spider-Verse+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Spider-Man+Across+the+Spider-Verse+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.6",
    views: 11300,
    isFeatured: true,
    isPublished: true,
    createdAt: new Date("2026-09-12"),
    updatedAt: new Date("2026-09-12"),
  },
];

export async function getDb() {
  if (!_db && ENV.databaseUrl) {
    try {
      _db = drizzle(ENV.databaseUrl);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function publishedOnly<T extends Movie>(rows: T[]) {
  return rows.filter(movie => movie.isPublished);
}

export async function listMovies(options: { kind?: "featured" | "popular" | "latest"; query?: string; limit?: number } = {}) {
  const db = await getDb();
  const limit = Math.min(Math.max(options.limit ?? 24, 1), 60);
  if (!db) {
    let rows = publishedOnly([...demoMovies]);
    if (options.query) {
      const q = options.query.toLowerCase();
      rows = rows.filter(movie => [movie.code, movie.title, movie.genre, movie.originalTitle].some(value => value?.toLowerCase().includes(q)));
    }
    if (options.kind === "featured") rows = rows.filter(movie => movie.isFeatured);
    if (options.kind === "popular") rows.sort((a, b) => b.views - a.views);
    if (options.kind === "latest") rows.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return rows.slice(0, limit);
  }

  const filters = [eq(movies.isPublished, true)];
  if (options.kind === "featured") filters.push(eq(movies.isFeatured, true));
  if (options.query) {
    const q = `%${options.query}%`;
    filters.push(or(like(movies.code, q), like(movies.title, q), like(movies.genre, q), like(movies.originalTitle, q))!);
  }
  let query = db.select().from(movies).where(and(...filters)).$dynamic();
  if (options.kind === "popular") query = query.orderBy(desc(movies.views));
  else if (options.kind === "latest") query = query.orderBy(desc(movies.createdAt));
  else query = query.orderBy(desc(movies.isFeatured), desc(movies.views));
  const rows = await query.limit(limit);
  if (rows.length) return rows;
  let fallback = publishedOnly([...demoMovies]);
  if (options.query) {
    const q = options.query.toLowerCase();
    fallback = fallback.filter(movie => [movie.code, movie.title, movie.genre, movie.originalTitle].some(value => value?.toLowerCase().includes(q)));
  }
  if (options.kind === "featured") fallback = fallback.filter(movie => movie.isFeatured);
  if (options.kind === "popular") fallback.sort((a, b) => b.views - a.views);
  if (options.kind === "latest") fallback.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  return fallback.slice(0, limit);
}

export async function getAdminStats() {
  const db = await getDb();
  if (!db) {
    const totalViews = demoMovies.reduce((sum, movie) => sum + movie.views, 0);
    return {
      totalUsers: 0,
      subscribedUsers: 0,
      totalMovies: demoMovies.length,
      publishedMovies: demoMovies.filter(movie => movie.isPublished).length,
      totalViews,
      topMovies: [...demoMovies].sort((a, b) => b.views - a.views).slice(0, 5).map(movie => ({ title: movie.title, code: movie.code, views: movie.views })),
    };
  }
  const [userCounts, movieCounts, viewTotals, topMovies] = await Promise.all([
    db.select({ total: sql<number>`count(*)`, subscribed: sql<number>`coalesce(sum(${telegramUsers.subscribed}), 0)` }).from(telegramUsers),
    db.select({ total: sql<number>`count(*)`, published: sql<number>`coalesce(sum(${movies.isPublished}), 0)` }).from(movies),
    db.select({ total: sql<number>`coalesce(sum(${movies.views}), 0)` }).from(movies),
    db.select({ title: movies.title, code: movies.code, views: movies.views }).from(movies).orderBy(desc(movies.views)).limit(5),
  ]);
  return {
    totalUsers: Number(userCounts[0]?.total || 0),
    subscribedUsers: Number(userCounts[0]?.subscribed || 0),
    totalMovies: Number(movieCounts[0]?.total || 0),
    publishedMovies: Number(movieCounts[0]?.published || 0),
    totalViews: Number(viewTotals[0]?.total || 0),
    topMovies,
  };
}

export async function listAllMovies() {
  const db = await getDb();
  if (!db) return [...demoMovies].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  return db.select().from(movies).orderBy(desc(movies.createdAt));
}

export async function getMovieById(id: number) {
  const db = await getDb();
  if (!db) return demoMovies.find(movie => movie.id === id);
  const result = await db.select().from(movies).where(eq(movies.id, id)).limit(1);
  return result[0] ?? publishedOnly(demoMovies).find(movie => movie.id === id);
}

export async function getMovieByCode(code: string) {
  const normalized = code.trim().toUpperCase();
  const db = await getDb();
  if (!db) return publishedOnly(demoMovies).find(movie => movie.code.toUpperCase() === normalized);
  const result = await db.select().from(movies).where(and(eq(movies.code, normalized), eq(movies.isPublished, true))).limit(1);
  return result[0] ?? publishedOnly(demoMovies).find(movie => movie.code.toUpperCase() === normalized);
}

export async function wasTelegramMovieDelivered(chatId: string, movieId: number) {
  const key = `${chatId}:${movieId}`;
  const db = await getDb();
  if (!db) return demoTelegramDeliveries.has(key);
  const result = await db.select().from(telegramDeliveries).where(and(eq(telegramDeliveries.chatId, chatId), eq(telegramDeliveries.movieId, movieId))).limit(1);
  return result.length > 0;
}

export async function markTelegramMovieDelivered(chatId: string, movieId: number) {
  const key = `${chatId}:${movieId}`;
  const db = await getDb();
  if (!db) {
    demoTelegramDeliveries.add(key);
    return;
  }
  try {
    await db.insert(telegramDeliveries).values({ chatId, movieId });
  } catch (error) {
    if (!String(error).toLowerCase().includes("duplicate")) throw error;
  }
}

export async function upsertTelegramUser(chatId: string, username?: string, firstName?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(telegramUsers).values({ chatId, username: username || null, firstName: firstName || null, lastSeenAt: new Date(), subscribed: true }).onDuplicateKeyUpdate({ set: { username: username || null, firstName: firstName || null, lastSeenAt: new Date(), subscribed: true } });
}

export async function listTelegramChatIds() {
  const db = await getDb();
  if (!db) return [] as string[];
  const rows = await db.select({ chatId: telegramUsers.chatId }).from(telegramUsers).where(eq(telegramUsers.subscribed, true));
  return rows.map(row => row.chatId);
}

export async function setTelegramSubscription(chatId: string, subscribed: boolean) {
  const db = await getDb();
  if (!db) return;
  await db.update(telegramUsers).set({ subscribed, lastSeenAt: new Date() }).where(eq(telegramUsers.chatId, chatId));
}

export async function createAnnouncement(text: string, sentCount: number, failedCount: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(telegramAnnouncements).values({ text, sentCount, failedCount });
}

export async function listAnnouncements(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(telegramAnnouncements).orderBy(desc(telegramAnnouncements.createdAt)).limit(limit);
}

export async function incrementMovieViews(id: number) {
  const db = await getDb();
  if (!db) {
    const movie = demoMovies.find(item => item.id === id);
    if (movie) movie.views += 1;
    return movie;
  }
  await db.update(movies).set({ views: sql`${movies.views} + 1` }).where(eq(movies.id, id));
  const movie = await getMovieById(id);
  if (movie) return movie;
  const demoMovie = demoMovies.find(item => item.id === id);
  if (demoMovie) demoMovie.views += 1;
  return demoMovie;
}

async function nextMovieCode() {
  const allMovies = await listAllMovies();
  const allKnownMovies = [...demoMovies, ...allMovies];
  const highest = allKnownMovies.reduce((max, movie) => {
    const match = movie.code?.match(/^KINO(\d+)$/i);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0);
  return `KINO${String(highest + 1).padStart(3, "0")}`;
}

export async function createMovie(input: Omit<InsertMovie, "code"> & { code?: string }) {
  const code = input.code?.trim().toUpperCase() || await nextMovieCode();
  const movieInput = { ...input, code } as InsertMovie;
  const db = await getDb();
  if (!db) {
    const id = Math.max(...demoMovies.map(movie => movie.id), 0) + 1;
    const movie = { ...movieInput, id, views: input.views ?? 0, isFeatured: input.isFeatured ?? false, isPublished: input.isPublished ?? true, createdAt: new Date(), updatedAt: new Date() } as Movie;
    demoMovies.unshift(movie);
    return movie;
  }
  const result = await db.insert(movies).values(movieInput);
  return getMovieById(Number(result[0].insertId));
}

export async function updateMovie(id: number, input: Partial<InsertMovie>) {
  const db = await getDb();
  if (!db) {
    const movie = demoMovies.find(item => item.id === id);
    if (!movie) return undefined;
    Object.assign(movie, input, { updatedAt: new Date() });
    return movie;
  }
  await db.update(movies).set(input).where(eq(movies.id, id));
  return getMovieById(id);
}

export async function deleteMovie(id: number) {
  const db = await getDb();
  if (!db) {
    const index = demoMovies.findIndex(item => item.id === id);
    if (index >= 0) demoMovies.splice(index, 1);
    return index >= 0;
  }
  await db.delete(telegramDeliveries).where(eq(telegramDeliveries.movieId, id));
  await db.delete(movies).where(eq(movies.id, id));
  return true;
}

export async function listSeries(options: { query?: string; kind?: "featured" | "popular" | "latest"; limit?: number } = {}) {
  const db = await getDb();
  if (!db) return [] as Series[];
  const limit = Math.min(Math.max(options.limit ?? 24, 1), 60);
  const filters = [eq(series.isPublished, true)];
  if (options.kind === "featured") filters.push(eq(series.isFeatured, true));
  if (options.query) {
    const q = `%${options.query}%`;
    filters.push(or(like(series.code, q), like(series.title, q), like(series.genre, q), like(series.originalTitle, q))!);
  }
  let query = db.select().from(series).where(and(...filters)).$dynamic();
  if (options.kind === "popular") query = query.orderBy(desc(series.views));
  else if (options.kind === "latest") query = query.orderBy(desc(series.createdAt));
  else query = query.orderBy(desc(series.isFeatured), desc(series.views));
  return query.limit(limit);
}

export async function listAllSeries() {
  const db = await getDb();
  if (!db) return [] as Series[];
  return db.select().from(series).orderBy(desc(series.createdAt));
}

export async function getSeriesById(id: number, admin = false) {
  const db = await getDb();
  if (!db) return undefined;
  const found = await db.select().from(series).where(and(eq(series.id, id), ...(admin ? [] : [eq(series.isPublished, true)]))).limit(1);
  return found[0];
}

export async function getSeriesByCode(code: string, admin = false) {
  const normalized = code.trim().toUpperCase();
  const db = await getDb();
  if (!db) return undefined;
  const found = await db.select().from(series).where(and(eq(series.code, normalized), ...(admin ? [] : [eq(series.isPublished, true)]))).limit(1);
  return found[0];
}

export async function getSeriesDetail(id: number, admin = false) {
  const item = await getSeriesById(id, admin);
  if (!item) return undefined;
  const db = await getDb();
  if (!db) return { series: item, seasons: [] };
  const seasonFilters = [eq(seriesSeasons.seriesId, id)];
  const seasons = await db.select().from(seriesSeasons).where(and(...seasonFilters)).orderBy(seriesSeasons.seasonNumber);
  const seasonDetails = await Promise.all(seasons.map(async season => {
    const episodeFilters = [eq(seriesEpisodes.seasonId, season.id)];
    if (!admin) episodeFilters.push(eq(seriesEpisodes.isPublished, true));
    const episodes = await db.select().from(seriesEpisodes).where(and(...episodeFilters)).orderBy(seriesEpisodes.episodeNumber);
    return { season, episodes };
  }));
  return { series: item, seasons: seasonDetails };
}

export async function getSeriesDetailByCode(code: string, admin = false) {
  const item = await getSeriesByCode(code, admin);
  return item ? getSeriesDetail(item.id, admin) : undefined;
}

async function nextSeriesCode() {
  const db = await getDb();
  if (!db) return "SER001";
  const rows = await db.select({ code: series.code }).from(series);
  const highest = rows.reduce((max, row) => {
    const match = row.code?.match(/^SER(\d+)$/i);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0);
  return `SER${String(highest + 1).padStart(3, "0")}`;
}

export async function createSeries(input: Omit<InsertSeries, "code"> & { code?: string }) {
  const code = input.code?.trim().toUpperCase() || await nextSeriesCode();
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(series).values({ ...input, code });
  return getSeriesById(Number(result[0].insertId), true);
}

export async function updateSeries(id: number, input: Partial<InsertSeries>) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(series).set(input).where(eq(series.id, id));
  return getSeriesById(id, true);
}

export async function createSeriesSeason(input: InsertSeriesSeason) {
  const db = await getDb();
  if (!db) return undefined;
  const parent = await getSeriesById(input.seriesId, true);
  if (!parent) return undefined;
  const result = await db.insert(seriesSeasons).values(input);
  return db.select().from(seriesSeasons).where(eq(seriesSeasons.id, Number(result[0].insertId))).limit(1).then(rows => rows[0]);
}

export async function updateSeriesSeason(id: number, input: Partial<InsertSeriesSeason>) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(seriesSeasons).set(input).where(eq(seriesSeasons.id, id));
  return db.select().from(seriesSeasons).where(eq(seriesSeasons.id, id)).limit(1).then(rows => rows[0]);
}

export async function createSeriesEpisode(input: InsertSeriesEpisode) {
  const db = await getDb();
  if (!db) return undefined;
  const parent = await db.select().from(seriesSeasons).where(eq(seriesSeasons.id, input.seasonId)).limit(1);
  if (!parent[0]) return undefined;
  const result = await db.insert(seriesEpisodes).values(input);
  return db.select().from(seriesEpisodes).where(eq(seriesEpisodes.id, Number(result[0].insertId))).limit(1).then(rows => rows[0]);
}

export async function updateSeriesEpisode(id: number, input: Partial<InsertSeriesEpisode>) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(seriesEpisodes).set(input).where(eq(seriesEpisodes.id, id));
  return db.select().from(seriesEpisodes).where(eq(seriesEpisodes.id, id)).limit(1).then(rows => rows[0]);
}

export async function getSeriesEpisodeById(id: number, admin = false) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select({ episode: seriesEpisodes, season: seriesSeasons, series }).from(seriesEpisodes).innerJoin(seriesSeasons, eq(seriesEpisodes.seasonId, seriesSeasons.id)).innerJoin(series, eq(seriesSeasons.seriesId, series.id)).where(and(eq(seriesEpisodes.id, id), ...(admin ? [] : [eq(seriesEpisodes.isPublished, true), eq(series.isPublished, true)]))).limit(1);
  return rows[0];
}

export async function attachSeriesEpisodeVideo(seriesCode: string, seasonNumber: number, episodeNumber: number, telegramFileId: string, telegramFileType: string) {
  const item = await getSeriesByCode(seriesCode, true);
  if (!item) return undefined;
  const db = await getDb();
  if (!db) return undefined;
  const season = await db.select().from(seriesSeasons).where(and(eq(seriesSeasons.seriesId, item.id), eq(seriesSeasons.seasonNumber, seasonNumber))).limit(1);
  if (!season[0]) return undefined;
  const episode = await db.select().from(seriesEpisodes).where(and(eq(seriesEpisodes.seasonId, season[0].id), eq(seriesEpisodes.episodeNumber, episodeNumber))).limit(1);
  if (!episode[0]) return undefined;
  await db.update(seriesEpisodes).set({ telegramFileId, telegramFileType }).where(eq(seriesEpisodes.id, episode[0].id));
  return getSeriesEpisodeById(episode[0].id, true);
}

export async function wasTelegramEpisodeDelivered(chatId: string, episodeId: number) {
  const db = await getDb();
  if (!db) return false;
  const rows = await db.select().from(telegramEpisodeDeliveries).where(and(eq(telegramEpisodeDeliveries.chatId, chatId), eq(telegramEpisodeDeliveries.episodeId, episodeId))).limit(1);
  return rows.length > 0;
}

export async function markTelegramEpisodeDelivered(chatId: string, episodeId: number) {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(telegramEpisodeDeliveries).values({ chatId, episodeId });
  } catch (error) {
    if (!String(error).toLowerCase().includes("duplicate")) throw error;
  }
}

export async function incrementSeriesViews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(series).set({ views: sql`${series.views} + 1` }).where(eq(series.id, id));
}

export async function incrementSeriesEpisodeViews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(seriesEpisodes).set({ views: sql`${seriesEpisodes.views} + 1` }).where(eq(seriesEpisodes.id, id));
}

export async function deleteSeriesEpisode(id: number) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(telegramEpisodeDeliveries).where(eq(telegramEpisodeDeliveries.episodeId, id));
  await db.delete(seriesEpisodes).where(eq(seriesEpisodes.id, id));
  return true;
}

export async function deleteSeriesSeason(id: number) {
  const db = await getDb();
  if (!db) return false;
  const episodes = await db.select({ id: seriesEpisodes.id }).from(seriesEpisodes).where(eq(seriesEpisodes.seasonId, id));
  for (const episode of episodes) await deleteSeriesEpisode(episode.id);
  await db.delete(seriesSeasons).where(eq(seriesSeasons.id, id));
  return true;
}

export async function deleteSeries(id: number) {
  const db = await getDb();
  if (!db) return false;
  const seasons = await db.select({ id: seriesSeasons.id }).from(seriesSeasons).where(eq(seriesSeasons.seriesId, id));
  for (const season of seasons) await deleteSeriesSeason(season.id);
  await db.delete(series).where(eq(series.id, id));
  return true;
}
