import { Button } from "@/components/ui/button";
import type { Movie } from "../../../drizzle/schema";
import { ArrowLeft, Check, Edit3, Film, KeyRound, LogOut, Megaphone, Plus, Save, Send, Trash2, X } from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

type MovieDraft = {
  code: string; title: string; originalTitle: string; year: string; genre: string; language: string; country: string; description: string; posterUrl: string; backdropUrl: string; watchUrl: string; trailerUrl: string; rating: string; isFeatured: boolean; isPublished: boolean;
};

const blankDraft: MovieDraft = { code: "", title: "", originalTitle: "", year: "", genre: "", language: "O‘zbekcha tarjima", country: "", description: "", posterUrl: "", backdropUrl: "", watchUrl: "", trailerUrl: "", rating: "", isFeatured: false, isPublished: true };

function fromMovie(movie: Movie): MovieDraft {
  return { code: movie.code, title: movie.title, originalTitle: movie.originalTitle || "", year: movie.year?.toString() || "", genre: movie.genre || "", language: movie.language || "", country: movie.country || "", description: movie.description || "", posterUrl: movie.posterUrl || "", backdropUrl: movie.backdropUrl || "", watchUrl: movie.watchUrl || "", trailerUrl: movie.trailerUrl || "", rating: movie.rating || "", isFeatured: movie.isFeatured, isPublished: movie.isPublished };
}

export default function Admin() {
  const [token, setToken] = useState(() => localStorage.getItem("kino-admin-token") || "");
  const [tokenInput, setTokenInput] = useState("");
  const [draft, setDraft] = useState<MovieDraft>(blankDraft);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [notice, setNotice] = useState("");
  const [announcement, setAnnouncement] = useState("");
  const login = trpc.admin.login.useMutation();
  const movies = trpc.admin.list.useQuery(undefined, { enabled: Boolean(token) });
  const stats = trpc.admin.stats.useQuery(undefined, { enabled: Boolean(token) });
  const create = trpc.admin.create.useMutation({ onSuccess: movie => { movies.refetch(); stats.refetch(); resetForm(); setNotice(`Film katalogga qo‘shildi. Avtomatik kod: ${movie?.code || "—"}`); } });
  const update = trpc.admin.update.useMutation({ onSuccess: () => { movies.refetch(); stats.refetch(); resetForm(); setNotice("Film yangilandi."); } });
  const remove = trpc.admin.delete.useMutation({ onSuccess: () => { movies.refetch(); stats.refetch(); setNotice("Film o‘chirildi."); } });
  const broadcast = trpc.admin.broadcast.useMutation({ onSuccess: result => { setAnnouncement(""); announcements.refetch(); setNotice(`E’lon yuborildi: ${result.sent} ta foydalanuvchi oldi.`); } });
  const announcements = trpc.admin.announcements.useQuery(undefined, { enabled: Boolean(token) });

  const submitLogin = (event: FormEvent) => {
    event.preventDefault();
    login.mutate({ token: tokenInput }, { onSuccess: result => { if (result.success) { localStorage.setItem("kino-admin-token", tokenInput); setToken(tokenInput); setNotice("Admin panelga xush kelibsiz."); } else setNotice("Token noto‘g‘ri."); } });
  };
  const logout = () => { localStorage.removeItem("kino-admin-token"); setToken(""); };
  const resetForm = () => { setDraft(blankDraft); setEditingId(null); };
  const editMovie = (movie: Movie) => { setEditingId(movie.id); setDraft(fromMovie(movie)); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const updateDraft = (key: keyof MovieDraft, value: string | boolean) => setDraft(current => ({ ...current, [key]: value }));
  const payload = useMemo(() => ({ ...draft, year: draft.year ? Number(draft.year) : null, originalTitle: draft.originalTitle || null, genre: draft.genre || null, language: draft.language || null, country: draft.country || null, description: draft.description || null, posterUrl: draft.posterUrl || null, backdropUrl: draft.backdropUrl || null, watchUrl: draft.watchUrl || null, trailerUrl: draft.trailerUrl || null, rating: draft.rating || null }), [draft]);
  const submitMovie = (event: FormEvent) => { event.preventDefault(); if (editingId) update.mutate({ id: editingId, ...payload }); else create.mutate(payload); };

  if (!token) return <div className="admin-gate"><div className="admin-gate-card"><Link href="/" className="back-link"><ArrowLeft size={16} /> Katalogga qaytish</Link><div className="admin-emblem"><KeyRound size={24} /></div><span className="eyebrow">PRIVATE STUDIO / ADMIN</span><h1>Admin panel</h1><p>Katalogni boshqarish uchun maxsus tokenni kiriting.</p><form onSubmit={submitLogin}><label>Admin token<input type="password" value={tokenInput} onChange={event => setTokenInput(event.target.value)} placeholder="Render ENV: ADMIN_TOKEN" autoComplete="current-password" /></label><Button className="full-button" type="submit" disabled={login.isPending}>{login.isPending ? "Tekshirilmoqda..." : "Panelni ochish"}</Button></form>{notice && <div className="form-notice error">{notice}</div>}</div></div>;

  return (
    <div className="admin-shell">
      <header className="admin-topbar"><Link href="/" className="brand"><span className="brand-mark"><Film size={16} /></span><span>KINOBOT <small>STUDIO</small></span></Link><div className="admin-actions"><span className="admin-status"><span /> LIVE CATALOG</span><button onClick={logout} className="logout-button"><LogOut size={15} /> Chiqish</button></div></header>
      <main className="admin-content">
        <div className="admin-heading"><div><span className="eyebrow">CONTENT CONTROL / 01</span><h1>Film katalogi</h1><p>Kod, havola va tavsiyalarni bir joydan boshqaring.</p></div><Link href="/" className="back-link"><ArrowLeft size={16} /> Ilovani ko‘rish</Link></div>
        <section className="stats-section"><div className="list-header"><div><span className="eyebrow">LIVE METRICS / OVERVIEW</span><h2>Statistika</h2></div><button className="refresh-button" onClick={() => stats.refetch()}>Yangilash</button></div><div className="stats-grid"><div className="stat-card"><span>Bot foydalanuvchilari</span><strong>{stats.data?.totalUsers?.toLocaleString("uz-UZ") || "—"}</strong><small>{stats.data?.subscribedUsers?.toLocaleString("uz-UZ") || "0"} ta faol obunachi</small></div><div className="stat-card"><span>Filmlar</span><strong>{stats.data?.totalMovies?.toLocaleString("uz-UZ") || "—"}</strong><small>{stats.data?.publishedMovies?.toLocaleString("uz-UZ") || "0"} ta nashrda</small></div><div className="stat-card"><span>Umumiy ko‘rishlar</span><strong>{stats.data?.totalViews?.toLocaleString("uz-UZ") || "—"}</strong><small>Katalogdagi barcha filmlar</small></div><div className="stat-card top-stat"><span>Eng mashhur filmlar</span>{stats.data?.topMovies?.length ? stats.data.topMovies.slice(0, 3).map(movie => <div className="top-movie" key={movie.code}><b>{movie.code}</b><em>{movie.title}</em><strong>{movie.views.toLocaleString("uz-UZ")}</strong></div>) : <small>Ma’lumot yo‘q</small>}</div></div></section>
        <section className="announcement-panel">
          <div className="announcement-copy"><div className="section-icon orange"><Megaphone size={18} /></div><div><span className="eyebrow">BROADCAST / BOT USERS</span><h2>Foydalanuvchilarga e’lon</h2><p>Botda Start bosgan foydalanuvchilarga xabar yuboriladi.</p></div></div>
          <form onSubmit={event => { event.preventDefault(); if (announcement.trim() && confirm("Bu e’lon bot foydalanuvchilariga yuborilsinmi?")) broadcast.mutate({ text: announcement.trim() }); }} className="announcement-form"><textarea value={announcement} onChange={event => setAnnouncement(event.target.value)} maxLength={4096} rows={3} placeholder="Masalan: Bugun yangi film qo‘shildi..." /><Button type="submit" disabled={broadcast.isPending || announcement.trim().length < 2}><Send size={16} /> {broadcast.isPending ? "Yuborilmoqda..." : "E’lon yuborish"}</Button></form>
        </section>
        <section className="announcement-history"><div className="list-header"><div><span className="eyebrow">HISTORY / BROADCASTS</span><h2>E’lonlar tarixi</h2></div></div>{announcements.data?.length ? announcements.data.map(item => <div className="history-row" key={item.id}><span>{new Date(item.createdAt).toLocaleString("uz-UZ")}</span><strong>{item.sentCount} yuborildi · {item.failedCount} xato</strong><p>{item.text}</p></div>) : <div className="empty-state">Hali e’lon yuborilmagan.</div>}</section>
        {notice && <div className="form-notice success"><Check size={16} /> {notice}<button onClick={() => setNotice("")}><X size={14} /></button></div>}
        <section className="admin-layout">
          <form className="movie-form" onSubmit={submitMovie}><div className="form-header"><div><span className="eyebrow">{editingId ? "EDIT RELEASE" : "NEW RELEASE"}</span><h2>{editingId ? "Filmni tahrirlash" : "Yangi film qo‘shish"}</h2></div>{editingId && <button type="button" className="icon-button" onClick={resetForm}><X size={17} /></button>}</div><div className="form-grid two"><label>Kino kodi (ixtiyoriy — bo‘sh qoldirsangiz avtomatik)<input value={draft.code} onChange={event => updateDraft("code", event.target.value)} placeholder="Avtomatik KINO006" /></label><label>Nomi<input required value={draft.title} onChange={event => updateDraft("title", event.target.value)} placeholder="Film nomi" /></label><label>Original nomi<input value={draft.originalTitle} onChange={event => updateDraft("originalTitle", event.target.value)} placeholder="Original title" /></label><label>Yil<input type="number" min="1888" max="2200" value={draft.year} onChange={event => updateDraft("year", event.target.value)} placeholder="2026" /></label><label>Janr<input value={draft.genre} onChange={event => updateDraft("genre", event.target.value)} placeholder="Drama · Jangari" /></label><label>Reyting<input value={draft.rating} onChange={event => updateDraft("rating", event.target.value)} placeholder="8.4" /></label><label>Til<input value={draft.language} onChange={event => updateDraft("language", event.target.value)} placeholder="O‘zbekcha tarjima" /></label><label>Mamlakat<input value={draft.country} onChange={event => updateDraft("country", event.target.value)} placeholder="AQSH" /></label></div><label>Tavsif<textarea rows={4} value={draft.description} onChange={event => updateDraft("description", event.target.value)} placeholder="Film haqida qisqacha..." /></label><div className="form-divider"><span>MEDIA & LINKS</span></div><label>Poster URL<input type="url" value={draft.posterUrl} onChange={event => updateDraft("posterUrl", event.target.value)} placeholder="https://..." /></label><label>Fon rasmi URL<input type="url" value={draft.backdropUrl} onChange={event => updateDraft("backdropUrl", event.target.value)} placeholder="https://..." /></label><label>Tomosha URL<input type="url" value={draft.watchUrl} onChange={event => updateDraft("watchUrl", event.target.value)} placeholder="https://rasmiy-manba.uz/..." /></label><label>Treyler URL<input type="url" value={draft.trailerUrl} onChange={event => updateDraft("trailerUrl", event.target.value)} placeholder="https://youtube.com/..." /></label><div className="toggle-row"><label className="check-label"><input type="checkbox" checked={draft.isFeatured} onChange={event => updateDraft("isFeatured", event.target.checked)} /><span>Featured tavsiya</span></label><label className="check-label"><input type="checkbox" checked={draft.isPublished} onChange={event => updateDraft("isPublished", event.target.checked)} /><span>Darhol nashr qilish</span></label></div><div className="form-actions"><Button type="submit" className="save-button" disabled={create.isPending || update.isPending}><Save size={16} /> {editingId ? "O‘zgarishni saqlash" : "Katalogga qo‘shish"}</Button>{editingId && <Button type="button" variant="outline" onClick={resetForm}>Bekor qilish</Button>}</div></form>
          <section className="admin-list"><div className="list-header"><div><span className="eyebrow">LIBRARY / {movies.data?.length || 0}</span><h2>Joylangan filmlar</h2></div><button className="add-small" onClick={resetForm}><Plus size={15} /> Yangi</button></div>{movies.isLoading ? <div className="empty-state">Katalog yuklanmoqda...</div> : movies.data?.map(movie => <div className="admin-movie-row" key={movie.id}><img src={movie.posterUrl || "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=160&q=80"} alt="" /><div className="admin-movie-info"><strong>{movie.title}</strong><span><b>{movie.code}</b> · {movie.year || "—"} · {movie.views.toLocaleString("uz-UZ")} ko‘rish</span><small className={movie.isPublished ? "published" : "draft"}>{movie.isPublished ? "NASHRDA" : "DRAFT"}{movie.isFeatured ? " · FEATURED" : ""}</small></div><div className="row-actions"><button onClick={() => editMovie(movie)} aria-label="Tahrirlash"><Edit3 size={16} /></button><button className="danger" onClick={() => { if (confirm(`${movie.title} o‘chirilsinmi?`)) remove.mutate({ id: movie.id }); }} aria-label="O‘chirish"><Trash2 size={16} /></button></div></div>)}</section>
        </section>
      </main>
    </div>
  );
}
