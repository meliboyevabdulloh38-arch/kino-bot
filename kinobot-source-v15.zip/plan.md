# KinoBot — Telegram Mini App MVP rejasi

## Talablar

- Telegram Mini App ko‘rinishidagi kino katalogi.
- Admin kinolarni joylaydi, tahrirlaydi va o‘chiradi.
- Foydalanuvchi kino kodini kiritib filmni qidiradi.
- Ilova foydalanuvchiga kinolarni tavsiya qiladi.
- Interfeys o‘zbek tilida bo‘ladi.
- Video manbasi faqat admin kiritgan ruxsatli tomosha havolasi sifatida saqlanadi; ilova noqonuniy nusxa ko‘chirmaydi.

## Amalga oshirish

React + Vite frontend, Express + tRPC backend va Drizzle/MySQL ma’lumotlar bazasi ishlatiladi. Telegram WebApp SDK ilovani bot ichida ishga tushirish, ranglar va oynani moslashtirish uchun ulanadi. Public katalog tRPC orqali film ro‘yxati, kod bo‘yicha qidiruv, film tafsilotlari va tavsiyalarni oladi. Admin panel film CRUD operatsiyalarini bajaradi va Render’da `ADMIN_TOKEN` orqali himoyalanadi. Mahalliy preview va baza ulanmagan holat uchun demo filmlar xotira fallback sifatida mavjud bo‘ladi.

## Asosiy oqimlar

1. Foydalanuvchi Mini App’ni ochadi va Telegram WebApp `ready()`/`expand()` chaqiriladi.
2. Bosh sahifada tavsiya etilgan, mashhur va yangi filmlar ko‘rsatiladi.
3. Foydalanuvchi kodni yoki film nomini qidiradi.
4. Film kartasi tafsilot sahifasida tavsif, janr, yil, reyting va rasmiy tomosha havolasi chiqadi.
5. Admin panelda token kiritilgach, film qo‘shish/tahrirlash/o‘chirish va nashr holatini boshqarish mumkin.

## Ma’lumotlar modeli

- `movies`: kod, nom, original nom, yil, janrlar, til, mamlakat, tavsif, poster, backdrop, tomosha havolasi, treyler, reyting, ko‘rishlar soni, nashr holati, featured holati, timestamps.
- `users`: starter’dagi platforma foydalanuvchilari va rollari saqlanadi.

## Loyiha tuzilmasi

- `client/src/pages/Home.tsx`: katalog, qidiruv, tavsiyalar va film tafsiloti.
- `client/src/pages/Admin.tsx`: admin CRUD boshqaruv paneli.
- `client/src/App.tsx`: public/admin routing.
- `client/src/index.css`: kino ilovasi uchun qoramtir, mobil-first dizayn.
- `server/routers.ts`: public katalog va admin tRPC endpointlari.
- `server/db.ts`: bazaga ulanish, movie query’lari va demo fallback.
- `drizzle/schema.ts`: `movies` jadvali.
- `public/manus-routes.json`: WebDev route manifest.

## Dizayn variantlari

- **Neon kino klubi — 0.07:** qoramtir sahna, kislota-lime aksentlar va yirik posterlar bilan tungi kino klub hissi.
- **Issiq kinoteatr — 0.05:** bordo, oltin va krem ranglar bilan klassik premyera kayfiyati.
- **Sokin streaming — 0.08:** sovuq ko‘k, yumshoq kulrang va keng bo‘shliqlar bilan servisga o‘xshash minimalizm.

### Tanlangan yo‘nalish: Neon kino klubi

- **Design Movement:** contemporary streaming noir + editorial film-poster art.
- **Core Principles:** tez topish, kuchli kontrast, poster markazli navigatsiya, mobil qulaylik.
- **Color Philosophy:** grafit fon kontentni sahnadagi ekran kabi ajratadi; neon lime harakat va tanlovni bildiradi; binafsha gradientlar tavsiya bloklariga kinematik chuqurlik beradi.
- **Layout Paradigm:** markazdagi oddiy grid o‘rniga tepada qidiruv “command bar”, yonlama poster rail’lar va tafsilotda katta cover-sahna ishlatiladi.
- **Signature Elements:** lime kod pill’i, poster ustidagi yumshoq gradient, “KODNI KIRIT” shaklidagi search capsule.
- **Interaction Philosophy:** foydalanuvchi har bir bosishda katalog ichida yo‘qolmaydi; kod qidiruvi doim ko‘rinadi, kartalar tez ochiladi, admin formasi qisqa va amaliy.
- **Animation:** posterlar hover’da sekin ko‘tariladi; qidiruv natijasi fade/slide bilan paydo bo‘ladi; harakatlar 180–260 ms oralig‘ida, bezak uchun emas, yo‘nalish uchun ishlatiladi.
- **Typography System:** `Manrope` asosiy UI uchun, `Space Grotesk` sarlavhalar va kodlar uchun; sarlavhalar zich, metadata esa kichik va harf oralig‘i keng.
- **Brand Essence:** Telegram ichida koddan bir zumda topiladigan, o‘zbekcha kino rafingiz. Shaxsiy, chaqqon, kinematik.
- **Brand Voice:** qisqa va do‘stona. Misollar: “Bugun nimani ko‘ramiz?” va “Kodni kiriting — film shu yerda.”
- **Wordmark & Logo:** “K” harfi ichida play uchburchagi bo‘lgan yumaloq belgi; wordmark yonida kichik `KOD` label’i.
- **Signature Brand Color:** `#D7FF42` neon lime.
