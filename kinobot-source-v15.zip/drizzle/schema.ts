import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const movies = mysqlTable("movies", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  originalTitle: varchar("originalTitle", { length: 255 }),
  year: int("year"),
  genre: varchar("genre", { length: 255 }),
  language: varchar("language", { length: 80 }),
  country: varchar("country", { length: 120 }),
  description: text("description"),
  posterUrl: text("posterUrl"),
  backdropUrl: text("backdropUrl"),
  watchUrl: text("watchUrl"),
  trailerUrl: text("trailerUrl"),
  telegramFileId: text("telegramFileId"),
  telegramFileType: varchar("telegramFileType", { length: 20 }),
  rating: varchar("rating", { length: 8 }).default("—"),
  views: int("views").default(0).notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  isPublished: boolean("isPublished").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const telegramDeliveries = mysqlTable("telegramDeliveries", {
  id: int("id").autoincrement().primaryKey(),
  chatId: varchar("chatId", { length: 64 }).notNull(),
  movieId: int("movieId").notNull(),
  deliveredAt: timestamp("deliveredAt").defaultNow().notNull(),
}, table => ({
  chatMovieUnique: uniqueIndex("chatMovieUnique").on(table.chatId, table.movieId),
}));

export const telegramUsers = mysqlTable("telegramUsers", {
  id: int("id").autoincrement().primaryKey(),
  chatId: varchar("chatId", { length: 64 }).notNull().unique(),
  username: varchar("username", { length: 255 }),
  firstName: varchar("firstName", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().notNull(),
  subscribed: boolean("subscribed").default(true).notNull(),
});

export const telegramAnnouncements = mysqlTable("telegramAnnouncements", {
  id: int("id").autoincrement().primaryKey(),
  text: text("text").notNull(),
  sentCount: int("sentCount").default(0).notNull(),
  failedCount: int("failedCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Movie = typeof movies.$inferSelect;
export type InsertMovie = typeof movies.$inferInsert;
