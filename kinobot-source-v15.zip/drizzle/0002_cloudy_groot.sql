ALTER TABLE `movies` ADD `telegramFileId` text;--> statement-breakpoint
ALTER TABLE `movies` ADD `telegramFileType` varchar(20);