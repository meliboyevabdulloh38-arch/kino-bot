CREATE TABLE `telegramDeliveries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`chatId` varchar(64) NOT NULL,
	`movieId` int NOT NULL,
	`deliveredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telegramDeliveries_id` PRIMARY KEY(`id`),
	CONSTRAINT `chatMovieUnique` UNIQUE(`chatId`,`movieId`)
);
