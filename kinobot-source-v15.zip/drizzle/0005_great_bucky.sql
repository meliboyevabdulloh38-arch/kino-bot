CREATE TABLE `telegramAnnouncements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`text` text NOT NULL,
	`sentCount` int NOT NULL DEFAULT 0,
	`failedCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telegramAnnouncements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `telegramUsers` ADD `subscribed` boolean DEFAULT true NOT NULL;