# KinoBot — Telegram Mini App

O‘zbekcha kino katalogi: foydalanuvchi kino kodini yoki nomini qidiradi, ilova esa admin joylagan filmni va ruxsatli tomosha havolasini ko‘rsatadi.

## Lokal ishga tushirish

```bash
pnpm install
cp .env.example .env
# .env ichida DATABASE_URL va ADMIN_TOKEN ni to‘ldiring
pnpm db:migrate
pnpm dev
```

`http://localhost:3000` manzilini oching. Baza ulanmagan holatda ham preview uchun demo filmlar chiqadi.

## Render deploy

1. Repozitoriyni GitHub’ga push qiling.
2. Render’da **Web Service** yarating.
3. Build command: `pnpm install --frozen-lockfile && pnpm build`
4. Start command: `pnpm start`
5. Environment variables qo‘shing: `DATABASE_URL` (tashqi MySQL provayderi, masalan PlanetScale yoki Aiven), `ADMIN_TOKEN`, `NODE_ENV=production`.
6. Deploy’dan keyin Render Shell’da `pnpm db:migrate` ishga tushiring yoki migratsiyani deploy pipeline’iga qo‘shing.
7. Telegram BotFather’da Mini App/Web App URL sifatida Render URL’ini ko‘rsating.

## Admin

`/admin` sahifasini oching va Render’dagi `ADMIN_TOKEN` qiymatini kiriting. Token browser `localStorage`da saqlanadi; logout qilganda o‘chiriladi. Ishlab chiqarishda uzun va tasodifiy token ishlating.

## Muhim

`watchUrl` faqat filmni tarqatish huquqi mavjud bo‘lgan yoki rasmiy tomosha manbasiga tegishli URL bo‘lishi kerak. Bot noqonuniy nusxalarni ko‘chirmaydi yoki qayta tarqatmaydi.
