# KinoBot MVP TODO

## 1. Telegram Mini App katalogi

- [x] Telegram Mini App ichida ishlaydigan o‘zbekcha, mobile-first kino katalogi bo‘lishi kerak.
- [x] Ilova ochilganda Telegram WebApp SDK `ready()` va `expand()` chaqirilib, Telegram ranglariga moslashishi kerak.
- [x] Bosh sahifada “Siz uchun”, “Mashhur” va “Yangi qo‘shilganlar” bo‘limlari ko‘rinishi kerak.
- [x] Film kartasida poster, nom, yil, janr va reyting ko‘rinishi kerak.

## 2. Kod va nom bo‘yicha qidiruv

- [x] Foydalanuvchi kino kodini kiritib aniq filmni topa olishi kerak.
- [x] Foydalanuvchi film nomi yoki janri bo‘yicha qidirishi kerak.
- [x] Natija topilmaganda foydalanuvchiga tushunarli o‘zbekcha holat ko‘rsatilishi kerak.
- [x] Film tafsilotida tavsif, metadata va admin kiritgan tomosha havolasi ko‘rinishi kerak.

## 3. Tavsiya tizimi

- [x] Ilova admin belgilagan featured filmlarni tavsiya qilishi kerak.
- [x] Mashhur filmlar ko‘rishlar soni bo‘yicha saralanishi kerak.
- [x] Har bir film ochilganda ko‘rishlar soni oshishi va keyingi tavsiyalarda ishlatilishi kerak.

## 4. Admin boshqaruvi

- [x] Admin token orqali himoyalangan admin sahifasiga kira olishi kerak.
- [x] Admin film qo‘shishi, tahrirlashi va o‘chirishi kerak.
- [x] Film maydonlari: kod, nom, yil, janr, til, tavsif, poster URL, backdrop URL, tomosha URL, treyler URL, reyting, featured va nashr holati.
- [x] Admin nashr qilinmagan filmni foydalanuvchilarga ko‘rsatmasligi kerak.
- [x] Admin panelda filmlar ro‘yxati va asosiy statistikasi ko‘rinishi kerak.

## 5. Render/GitHub uchun tayyorlash

- [x] `pnpm check` va `pnpm build` muvaffaqiyatli ishlashi kerak.
- [x] `/api/health` endpointi health check sifatida ishlashi kerak.
- [x] `DATABASE_URL` va `ADMIN_TOKEN` Render environment variables sifatida ishlatilishi kerak.
- [x] Ma’lumotlar bazasi migratsiyasi repozitoriyga kiritilishi kerak.
- [x] Route manifest `/manus-routes.json` ilovaning public va admin route’larini aks ettirishi kerak.
