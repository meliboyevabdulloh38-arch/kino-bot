export {};

declare global {
  interface Window {
    __MANUS_CONFIG__?: {
      projectId: string;
      oauthPortalUrl: string;
      apiUrl: string;
      apiBrowserKey: string;
    };
    Telegram?: {
      WebApp?: {
        ready: () => void;
        expand: () => void;
        close: () => void;
        openLink: (url: string) => void;
        themeParams?: { bg_color?: string; text_color?: string; button_color?: string };
        initDataUnsafe?: { user?: { id?: number; first_name?: string; username?: string } };
      };
    };
  }
}
