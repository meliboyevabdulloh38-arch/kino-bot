import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createMovie, deleteMovie, getMovieByCode, getMovieById, incrementMovieViews, listAllMovies, listAnnouncements, listMovies, updateMovie } from "./db";
import { publicProcedure, router } from "./_core/trpc";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { broadcastAnnouncement } from "./telegramBot";

const movieInput = z.object({
  code: z.string().trim().max(32).transform(value => value ? value.toUpperCase() : undefined).optional(),
  title: z.string().trim().min(2).max(255),
  originalTitle: z.string().trim().max(255).optional().nullable(),
  year: z.number().int().min(1888).max(2200).optional().nullable(),
  genre: z.string().trim().max(255).optional().nullable(),
  language: z.string().trim().max(80).optional().nullable(),
  country: z.string().trim().max(120).optional().nullable(),
  description: z.string().trim().max(5000).optional().nullable(),
  posterUrl: z.string().url().max(2000).optional().nullable().or(z.literal("")),
  backdropUrl: z.string().url().max(2000).optional().nullable().or(z.literal("")),
  watchUrl: z.string().url().max(2000).optional().nullable().or(z.literal("")),
  trailerUrl: z.string().url().max(2000).optional().nullable().or(z.literal("")),
  rating: z.string().trim().max(8).optional().nullable(),
  isFeatured: z.boolean().default(false),
  isPublished: z.boolean().default(true),
});

const adminProcedure = publicProcedure.use(async ({ ctx, next }) => {
  const configuredToken = process.env.ADMIN_TOKEN;
  const header = ctx.req.headers["x-admin-token"];
  const suppliedToken = typeof header === "string" ? header : undefined;
  if (!configuredToken || !suppliedToken || suppliedToken !== configuredToken) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Admin token noto‘g‘ri yoki sozlanmagan" });
  }
  return next();
});

export const appRouter = router({
  system: router({
    health: publicProcedure.query(() => ({ ok: true, service: "kinobot" })),
  }),
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  movies: router({
    recommendations: publicProcedure.query(async () => listMovies({ kind: "featured", limit: 8 })),
    popular: publicProcedure.query(async () => listMovies({ kind: "popular", limit: 8 })),
    latest: publicProcedure.query(async () => listMovies({ kind: "latest", limit: 8 })),
    search: publicProcedure.input(z.object({ query: z.string().trim().min(1).max(100) })).query(async ({ input }) => listMovies({ query: input.query, limit: 24 })),
    byCode: publicProcedure.input(z.object({ code: z.string().trim().min(1).max(32) })).query(async ({ input }) => getMovieByCode(input.code)),
    detail: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => getMovieById(input.id)),
    incrementViews: publicProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => incrementMovieViews(input.id)),
  }),
  admin: router({
    login: publicProcedure.input(z.object({ token: z.string().min(1) })).mutation(({ input }) => ({ success: Boolean(process.env.ADMIN_TOKEN && input.token === process.env.ADMIN_TOKEN) })),
    list: adminProcedure.query(() => listAllMovies()),
    create: adminProcedure.input(movieInput).mutation(({ input }) => createMovie(input)),
    update: adminProcedure.input(movieInput.extend({ id: z.number().int().positive() })).mutation(({ input }) => {
      const { id, ...data } = input;
      return updateMovie(id, data);
    }),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteMovie(input.id)),
    broadcast: adminProcedure.input(z.object({ text: z.string().trim().min(2).max(4096) })).mutation(({ input }) => broadcastAnnouncement(input.text)),
    announcements: adminProcedure.query(() => listAnnouncements()),
  }),
});

export type AppRouter = typeof appRouter;
