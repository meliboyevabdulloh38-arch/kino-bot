import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertMovie, InsertUser, Movie, movies, telegramAnnouncements, telegramDeliveries, telegramUsers, User, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
const demoTelegramDeliveries = new Set<string>();

const demoMovies: Movie[] = [
  {
    id: 1,
    code: "KINO001",
    title: "Interstellar",
    originalTitle: "Interstellar",
    year: 2014,
    genre: "Fantastika · Drama",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Insoniyat kelajagi uchun yangi sayyora izlayotgan tadqiqotchilar haqidagi epik kosmik sarguzasht.",
    posterUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Interstellar+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Interstellar+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.7",
    views: 12840,
    isFeatured: true,
    isPublished: true,
    createdAt: new Date("2026-09-01"),
    updatedAt: new Date("2026-09-01"),
  },
  {
    id: 2,
    code: "KINO002",
    title: "Dune: Part Two",
    originalTitle: "Dune: Part Two",
    year: 2024,
    genre: "Fantastika · Sarguzasht",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Pol Atreides Chani va fremenlar bilan birlashib, oilasi taqdiriga qarshi fitnaga yuz tutadi.",
    posterUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Dune+Part+Two+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Dune+Part+Two+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.8",
    views: 9820,
    isFeatured: true,
    isPublished: true,
    createdAt: new Date("2026-09-04"),
    updatedAt: new Date("2026-09-04"),
  },
  {
    id: 3,
    code: "KINO003",
    title: "The Batman",
    originalTitle: "The Batman",
    year: 2022,
    genre: "Jangari · Detektiv",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Gotham shahrida sirli jinoyatlar izidan borayotgan Batman o‘z shahrining qorong‘i sirlarini ochadi.",
    posterUrl: "https://images.unsplash.com/photo-1531259683007-016a7b628fc3?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=The+Batman+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=The+Batman+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "7.8",
    views: 7640,
    isFeatured: false,
    isPublished: true,
    createdAt: new Date("2026-09-06"),
    updatedAt: new Date("2026-09-06"),
  },
  {
    id: 4,
    code: "KINO004",
    title: "The Grand Budapest Hotel",
    originalTitle: "The Grand Budapest Hotel",
    year: 2014,
    genre: "Komediya · Drama",
    language: "O‘zbekcha tarjima",
    country: "Germaniya",
    description: "Mehmonxona konsyeri va uning yosh yordamchisi Yevropadagi eng katta meros mojarosiga tushib qoladi.",
    posterUrl: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Grand+Budapest+Hotel+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Grand+Budapest+Hotel+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.1",
    views: 5320,
    isFeatured: false,
    isPublished: true,
    createdAt: new Date("2026-09-10"),
    updatedAt: new Date("2026-09-10"),
  },
  {
    id: 5,
    code: "KINO005",
    title: "Spider-Man: Across the Spider-Verse",
    originalTitle: "Spider-Man: Across the Spider-Verse",
    year: 2023,
    genre: "Animatsiya · Fantastika",
    language: "O‘zbekcha tarjima",
    country: "AQSH",
    description: "Miles Morales multiverse bo‘ylab yangi jamoa va katta tanlov qarshisida qoladi.",
    posterUrl: "https://images.unsplash.com/photo-1534809027769-b00d750a6bac?auto=format&fit=crop&w=700&q=85",
    backdropUrl: "https://images.unsplash.com/photo-1518709594023-6eab9bab7b23?auto=format&fit=crop&w=1600&q=85",
    watchUrl: "https://www.youtube.com/results?search_query=Spider-Man+Across+the+Spider-Verse+official+watch",
    trailerUrl: "https://www.youtube.com/results?search_query=Spider-Man+Across+the+Spider-Verse+official+trailer",
    telegramFileId: null,
    telegramFileType: null,
    rating: "8.6",
    views: 11300,
    isFeatured: true,
    isPublished: true,
    createdAt: new Date("2026-09-12"),
    updatedAt: new Date("2026-09-12"),
  },
];

export async function getDb() {
  if (!_db && ENV.databaseUrl) {
    try {
      _db = drizzle(ENV.databaseUrl);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function publishedOnly<T extends Movie>(rows: T[]) {
  return rows.filter(movie => movie.isPublished);
}

export async function listMovies(options: { kind?: "featured" | "popular" | "latest"; query?: string; limit?: number } = {}) {
  const db = await getDb();
  const limit = Math.min(Math.max(options.limit ?? 24, 1), 60);
  if (!db) {
    let rows = publishedOnly([...demoMovies]);
    if (options.query) {
      const q = options.query.toLowerCase();
      rows = rows.filter(movie => [movie.code, movie.title, movie.genre, movie.originalTitle].some(value => value?.toLowerCase().includes(q)));
    }
    if (options.kind === "featured") rows = rows.filter(movie => movie.isFeatured);
    if (options.kind === "popular") rows.sort((a, b) => b.views - a.views);
    if (options.kind === "latest") rows.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return rows.slice(0, limit);
  }

  const filters = [eq(movies.isPublished, true)];
  if (options.kind === "featured") filters.push(eq(movies.isFeatured, true));
  if (options.query) {
    const q = `%${options.query}%`;
    filters.push(or(like(movies.code, q), like(movies.title, q), like(movies.genre, q), like(movies.originalTitle, q))!);
  }
  let query = db.select().from(movies).where(and(...filters)).$dynamic();
  if (options.kind === "popular") query = query.orderBy(desc(movies.views));
  else if (options.kind === "latest") query = query.orderBy(desc(movies.createdAt));
  else query = query.orderBy(desc(movies.isFeatured), desc(movies.views));
  const rows = await query.limit(limit);
  if (rows.length) return rows;
  let fallback = publishedOnly([...demoMovies]);
  if (options.query) {
    const q = options.query.toLowerCase();
    fallback = fallback.filter(movie => [movie.code, movie.title, movie.genre, movie.originalTitle].some(value => value?.toLowerCase().includes(q)));
  }
  if (options.kind === "featured") fallback = fallback.filter(movie => movie.isFeatured);
  if (options.kind === "popular") fallback.sort((a, b) => b.views - a.views);
  if (options.kind === "latest") fallback.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  return fallback.slice(0, limit);
}

export async function listAllMovies() {
  const db = await getDb();
  if (!db) return [...demoMovies].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  return db.select().from(movies).orderBy(desc(movies.createdAt));
}

export async function getMovieById(id: number) {
  const db = await getDb();
  if (!db) return demoMovies.find(movie => movie.id === id);
  const result = await db.select().from(movies).where(eq(movies.id, id)).limit(1);
  return result[0] ?? publishedOnly(demoMovies).find(movie => movie.id === id);
}

export async function getMovieByCode(code: string) {
  const normalized = code.trim().toUpperCase();
  const db = await getDb();
  if (!db) return publishedOnly(demoMovies).find(movie => movie.code.toUpperCase() === normalized);
  const result = await db.select().from(movies).where(and(eq(movies.code, normalized), eq(movies.isPublished, true))).limit(1);
  return result[0] ?? publishedOnly(demoMovies).find(movie => movie.code.toUpperCase() === normalized);
}

export async function wasTelegramMovieDelivered(chatId: string, movieId: number) {
  const key = `${chatId}:${movieId}`;
  const db = await getDb();
  if (!db) return demoTelegramDeliveries.has(key);
  const result = await db.select().from(telegramDeliveries).where(and(eq(telegramDeliveries.chatId, chatId), eq(telegramDeliveries.movieId, movieId))).limit(1);
  return result.length > 0;
}

export async function markTelegramMovieDelivered(chatId: string, movieId: number) {
  const key = `${chatId}:${movieId}`;
  const db = await getDb();
  if (!db) {
    demoTelegramDeliveries.add(key);
    return;
  }
  try {
    await db.insert(telegramDeliveries).values({ chatId, movieId });
  } catch (error) {
    if (!String(error).toLowerCase().includes("duplicate")) throw error;
  }
}

export async function upsertTelegramUser(chatId: string, username?: string, firstName?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(telegramUsers).values({ chatId, username: username || null, firstName: firstName || null, lastSeenAt: new Date(), subscribed: true }).onDuplicateKeyUpdate({ set: { username: username || null, firstName: firstName || null, lastSeenAt: new Date(), subscribed: true } });
}

export async function listTelegramChatIds() {
  const db = await getDb();
  if (!db) return [] as string[];
  const rows = await db.select({ chatId: telegramUsers.chatId }).from(telegramUsers).where(eq(telegramUsers.subscribed, true));
  return rows.map(row => row.chatId);
}

export async function setTelegramSubscription(chatId: string, subscribed: boolean) {
  const db = await getDb();
  if (!db) return;
  await db.update(telegramUsers).set({ subscribed, lastSeenAt: new Date() }).where(eq(telegramUsers.chatId, chatId));
}

export async function createAnnouncement(text: string, sentCount: number, failedCount: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(telegramAnnouncements).values({ text, sentCount, failedCount });
}

export async function listAnnouncements(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(telegramAnnouncements).orderBy(desc(telegramAnnouncements.createdAt)).limit(limit);
}

export async function incrementMovieViews(id: number) {
  const db = await getDb();
  if (!db) {
    const movie = demoMovies.find(item => item.id === id);
    if (movie) movie.views += 1;
    return movie;
  }
  await db.update(movies).set({ views: sql`${movies.views} + 1` }).where(eq(movies.id, id));
  const movie = await getMovieById(id);
  if (movie) return movie;
  const demoMovie = demoMovies.find(item => item.id === id);
  if (demoMovie) demoMovie.views += 1;
  return demoMovie;
}

async function nextMovieCode() {
  const allMovies = await listAllMovies();
  const allKnownMovies = [...demoMovies, ...allMovies];
  const highest = allKnownMovies.reduce((max, movie) => {
    const match = movie.code?.match(/^KINO(\d+)$/i);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0);
  return `KINO${String(highest + 1).padStart(3, "0")}`;
}

export async function createMovie(input: Omit<InsertMovie, "code"> & { code?: string }) {
  const code = input.code?.trim().toUpperCase() || await nextMovieCode();
  const movieInput = { ...input, code } as InsertMovie;
  const db = await getDb();
  if (!db) {
    const id = Math.max(...demoMovies.map(movie => movie.id), 0) + 1;
    const movie = { ...movieInput, id, views: input.views ?? 0, isFeatured: input.isFeatured ?? false, isPublished: input.isPublished ?? true, createdAt: new Date(), updatedAt: new Date() } as Movie;
    demoMovies.unshift(movie);
    return movie;
  }
  const result = await db.insert(movies).values(movieInput);
  return getMovieById(Number(result[0].insertId));
}

export async function updateMovie(id: number, input: Partial<InsertMovie>) {
  const db = await getDb();
  if (!db) {
    const movie = demoMovies.find(item => item.id === id);
    if (!movie) return undefined;
    Object.assign(movie, input, { updatedAt: new Date() });
    return movie;
  }
  await db.update(movies).set(input).where(eq(movies.id, id));
  return getMovieById(id);
}

export async function deleteMovie(id: number) {
  const db = await getDb();
  if (!db) {
    const index = demoMovies.findIndex(item => item.id === id);
    if (index >= 0) demoMovies.splice(index, 1);
    return index >= 0;
  }
  await db.delete(telegramDeliveries).where(eq(telegramDeliveries.movieId, id));
  await db.delete(movies).where(eq(movies.id, id));
  return true;
}
