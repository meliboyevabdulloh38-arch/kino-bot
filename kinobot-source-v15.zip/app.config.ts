export default {
  logoUrl: "https://cdn.simpleicons.org/telegram/ffffff",
};
