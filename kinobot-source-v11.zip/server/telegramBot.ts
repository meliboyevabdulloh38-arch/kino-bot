import { createMovie, getMovieByCode, markTelegramMovieDelivered, updateMovie, wasTelegramMovieDelivered } from "./db";

const token = process.env.TELEGRAM_BOT_TOKEN;
const adminId = process.env.TELEGRAM_ADMIN_ID;
const api = token ? `https://api.telegram.org/bot${token}` : "";
let offset = 0;
let running = false;

async function telegram(method: string, body: Record<string, unknown>) {
  if (!api) return null;
  const response = await fetch(`${api}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  return response.json() as Promise<{ ok: boolean; result?: any; description?: string }>;
}

async function handleUpdate(update: any) {
  const message = update.message;
  if (!message?.chat?.id) return;
  const chatId = message.chat.id;
  const fromId = String(message.from?.id ?? "");

  if (message.video || message.document?.mime_type?.startsWith("video/")) {
    if (adminId && fromId !== adminId) return;
    const caption = String(message.caption || "").trim();
    const code = caption.toUpperCase();
    const fileId = message.video?.file_id || message.document?.file_id;
    const fileType = message.video ? "video" : "document";
    const movie = /^KINO\d+$/.test(code) ? await getMovieByCode(code) : null;
    if (!movie && !/^KINO\d+$/.test(code)) {
      const fileName = message.video?.file_name || message.document?.file_name || "";
      const title = caption || fileName.replace(/\.[a-z0-9]+$/i, "").replace(/[._-]+/g, " ").trim() || "Yangi film";
      const created = await createMovie({
        title,
        telegramFileId: fileId,
        telegramFileType: fileType,
        isPublished: true,
      });
      if (!created) {
        await telegram("sendMessage", { chat_id: chatId, text: "Filmni saqlashda xatolik yuz berdi." });
        return;
      }
      await telegram("sendMessage", { chat_id: chatId, text: `${created.title} saqlandi. Avtomatik kod: ${created.code}` });
      return;
    }
    if (!movie) {
      await telegram("sendMessage", { chat_id: chatId, text: `${code} kodi bilan film topilmadi. Avval Admin panelda shu kodli filmni yarating.` });
      return;
    }
    await updateMovie(movie.id, { telegramFileId: fileId, telegramFileType: fileType });
    await telegram("sendMessage", { chat_id: chatId, text: `${movie.title} uchun video saqlandi. Endi foydalanuvchi Mini App ichidan “Botda ko‘rish”ni bosadi.` });
    return;
  }

  const text = String(message.text || "");
  const startMatch = text.match(/^\/start(?:\s+movie_(KINO\d+))?/i);
  const codeMatch = text.match(/^\/?(?:kino\s*)?(KINO\d+)$/i);
  const code = startMatch?.[1]?.toUpperCase() || codeMatch?.[1]?.toUpperCase();
  if (!code) {
    await telegram("sendMessage", { chat_id: chatId, text: "Kino kodini yuboring yoki Mini App ichidan filmni tanlang." });
    return;
  }
  const movie = await getMovieByCode(code);
  if (!movie?.telegramFileId) {
    await telegram("sendMessage", { chat_id: chatId, text: `${code} uchun video hali yuklanmagan.` });
    return;
  }
  const chatKey = String(chatId);
  if (await wasTelegramMovieDelivered(chatKey, movie.id)) {
    await telegram("sendMessage", { chat_id: chatId, text: `✅ ${movie.title} bu chatga avval yuborilgan. Yuqoridagi videoni oching.` });
    return;
  }
  const method = movie.telegramFileType === "document" ? "sendDocument" : "sendVideo";
  const sent = await telegram(method, { chat_id: chatId, [movie.telegramFileType === "document" ? "document" : "video"]: movie.telegramFileId, caption: `✅ Kino bot chatiga yuborildi\n${movie.title}\n${movie.year || ""}` });
  if (sent?.ok) await markTelegramMovieDelivered(chatKey, movie.id);
}

async function poll() {
  if (!api || running) return;
  running = true;
  while (running) {
    try {
      const response = await telegram("getUpdates", { offset, timeout: 25, allowed_updates: ["message"] });
      if (!response?.ok) throw new Error(response?.description || "Telegram API error");
      for (const update of response.result || []) {
        offset = update.update_id + 1;
        await handleUpdate(update);
      }
    } catch (error) {
      console.error("[Telegram bot]", error instanceof Error ? error.message : error);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
}

export function startTelegramBot() {
  if (!token) {
    console.log("[Telegram bot] TELEGRAM_BOT_TOKEN is not configured yet.");
    return;
  }
  console.log("[Telegram bot] polling started");
  void poll();
}
